import random
import string


def generate_password(length):
    lowercase = string.ascii_lowercase
    uppercase = string.ascii_uppercase
    numbers = string.digits
    symbols = string.punctuation

    all_characters = lowercase + uppercase + numbers + symbols

    password = ''.join(random.sample(all_characters, length))
    return password


password_length = int(input("Enter the length of the password: "))

print(f"Your random password is: {generate_password(password_length)}")